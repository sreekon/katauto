import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'Open the  Chrome Browser'
WebUI.openBrowser('')

'Navigate to URL ""'
WebUI.navigateToUrl('https://www.gamesforthebrain.com/game/checkers/')

'Verify that "Checkers" app is loaded successfully.'
WebUI.verifyElementText(findTestObject('Object Repository/Checkers_game/h1_Checkers'), 'Checkers')

'Verify that player with Orange pieces can make the first move'
WebUI.verifyElementText(findTestObject('Object Repository/Checkers_game/p_Select an orange piece to move'), 'Select an orange piece to move.')

'Verfiy that orange piece is ready to be clicked'
WebUI.verifyElementAttributeValue(findTestObject('Checkers_game/img_space42'), 'src', 'https://www.gamesforthebrain.com/game/checkers/you1.gif', 
    1, FailureHandling.STOP_ON_FAILURE)

'Select the orange piece at 42 square to move.'
WebUI.click(findTestObject('Checkers_game/img_space42'))

'Add a  wait '
WebUI.delay(1)

'Verfiy that orange piece is clicked and image state changed to bright'
WebUI.verifyElementAttributeValue(findTestObject('Checkers_game/img_space42'), 'src', 'https://www.gamesforthebrain.com/game/checkers/you2.gif', 
    1, FailureHandling.STOP_ON_FAILURE)

'Check if diagnol square is empty and orange piece can be moved'
WebUI.verifyElementAttributeValue(findTestObject('Checkers_game/img_space53'), 'src', 'https://www.gamesforthebrain.com/game/checkers/gray.gif', 
    1, FailureHandling.CONTINUE_ON_FAILURE)

'Click on 53 square to move the orange piece at 42 to 53 square'
WebUI.click(findTestObject('Checkers_game/img_space53'))

'Add a  wait '
WebUI.delay(1)

'Verify orange piece moved to 53 square'
WebUI.verifyElementAttributeValue(findTestObject('Checkers_game/img_space53'), 'src', 'https://www.gamesforthebrain.com/game/checkers/you1.gif', 
    3, FailureHandling.STOP_ON_FAILURE)

'Verify thatOrange piece can make a move with "Make a move." message\r\n'
WebUI.waitForElementPresent(findTestObject('Checkers_game/p_Make a move'), 2)

'Select the orange piece at 22 square to move.'
WebUI.click(findTestObject('Object Repository/Checkers_game/img_space22'))

'Add a delay'
WebUI.delay(2)

'Click on 33 square to move the orange piece at 22 to 33 square'
WebUI.click(findTestObject('Object Repository/Checkers_game/img_space33'))

'Add a wait.'
WebUI.delay(2)

'Verify that Orange piece in square33 is consumed by blue piece.'
WebUI.verifyElementAttributeValue(findTestObject('Checkers_game/img_space33'), 'src', 'https://www.gamesforthebrain.com/game/checkers/gray.gif', 
    2, FailureHandling.STOP_ON_FAILURE)

'Verify that Blue piece filled in square 42 and offering  exchange to 51'
WebUI.verifyElementAttributeValue(findTestObject('Checkers_game/img_space42'), 'src', 'https://www.gamesforthebrain.com/game/checkers/me1.gif', 
    2, FailureHandling.STOP_ON_FAILURE)

'Verify thatOrange piece can make a move with "Make a move." message\r\n'
WebUI.waitForElementPresent(findTestObject('Checkers_game/p_Make a move'), 2)

'Add a wait.'
WebUI.delay(2)

'Select the orange piece at 51 square to make an exhange with 42'
WebUI.click(findTestObject('Object Repository/Checkers_game/img_space51'))

'Add a delay'
WebUI.delay(2)

'Select square 33 to jump the blue piece in 42 - Test Case / Blue piece consumed'
WebUI.click(findTestObject('Object Repository/Checkers_game/img_space33'))

'Add a delay.'
WebUI.delay(3)

'Select the orange piece at 51 square to move.'
WebUI.click(findTestObject('Object Repository/Checkers_game/img_space53_1'))

'Add a delay'
WebUI.delay(2)

'Select 51 to move orange piece to 44 from  square 51'
WebUI.click(findTestObject('Object Repository/Checkers_game/img_space44'))

'Add a delay'
WebUI.delay(2)

'Select orange piece on square 62 to consume Blue piece on 53'
WebUI.click(findTestObject('Object Repository/Checkers_game/img_space62'))

'Add a delay'
WebUI.delay(2)

'Select square 44 to jump the blue piece in  53 - Test Case / Blue piece consumed'
WebUI.click(findTestObject('Object Repository/Checkers_game/img_space44'))

'Check if Restart link is available'
WebUI.verifyElementText(findTestObject('Object Repository/Checkers_game/a_Restart'), 'Restart...')

'Check if Restart is  clickable '
WebUI.verifyElementClickable(findTestObject('Object Repository/Checkers_game/a_Restart'))

'Click to restart the checkers app'
WebUI.click(findTestObject('Object Repository/Checkers_game/a_Restart'))

'Add a delay'
WebUI.delay(3)

'Verify that  "Select an orange peice to move." message is display to confirm app availability'
WebUI.verifyElementText(findTestObject('Object Repository/Checkers_game/p_Select an orange piece to move'), 'Select an orange piece to move.')

